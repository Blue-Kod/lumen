// Duck.ai provider: rolling x-vqd-hash-1 challenge, cookie jar, SSE chat.
// Direct port of providers/duckai.py (minus PIL image re-encoding).
import { solveVqd } from "./vqd.js";

const HOST = "https://duck.ai";

const USER_AGENTS = [
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0",
  "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:141.0) Gecko/20100101 Firefox/141.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
];

export const MODELS = {
  gpt56luna: { id: "gpt-5.6-luna", name: "GPT-5.6 Luna", desc: "Повседневное использование", effort: "low" },
  gpt54mini: { id: "gpt-5.4-mini", name: "GPT-5.4 mini", desc: "Быстрее тратит лимиты", effort: "low" },
  claude45: { id: "claude-haiku-4-5", name: "Claude Haiku 4.5", desc: "Быстрее тратит лимиты", effort: "low" },
  mistral4: { id: "mistral-small-2603", name: "Mistral Small 4", desc: null, effort: null },
  gptoss: { id: "tinfoil/gpt-oss-120b", name: "gpt-oss 120B", desc: null, effort: "low" },
  gemma4: { id: "tinfoil/gemma4-31b", name: "Gemma 4 31B", desc: "БЕТА", effort: "low" },
};

// --- Rolling VQD challenge --------------------------------------------------
// Duck.ai returns a fresh x-vqd-hash-1 in each chat response that must be
// solved and reused for the next message. Re-fetching /status on every message
// is rejected with HTTP 418.
let challenge = null;
let challengeUa = null;
const cookies = new Map();

function nextUa() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function storeCookies(resp) {
  let list = [];
  if (typeof resp.headers.getSetCookie === "function") {
    list = resp.headers.getSetCookie();
  } else {
    const raw = resp.headers.get("set-cookie");
    if (raw) list = raw.split(/,(?=[^;]+=)/);
  }
  for (const c of list) {
    const pair = c.split(";", 1)[0];
    const i = pair.indexOf("=");
    if (i > 0) cookies.set(pair.slice(0, i).trim(), pair.slice(i + 1).trim());
  }
}

function cookieHeader() {
  if (!cookies.size) return {};
  return { Cookie: [...cookies].map(([k, v]) => `${k}=${v}`).join("; ") };
}

async function getChallenge(ua) {
  const resp = await fetch(`${HOST}/duckchat/v1/status`, {
    headers: {
      accept: "*/*",
      "x-vqd-accept": "1",
      "User-Agent": ua,
      Referer: "https://duck.ai/",
      ...cookieHeader(),
    },
  });
  storeCookies(resp);
  await resp.arrayBuffer().catch(() => {});
  return resp.headers.get("x-vqd-hash-1");
}

async function getVqd() {
  let lastErr = null;
  for (let i = 0; i < 5; i++) {
    const ua = nextUa();
    let ch = null;
    try {
      ch = await getChallenge(ua);
    } catch {
      continue;
    }
    if (!ch) continue;
    try {
      return { vqd: await solveVqd(ch, ua), ua };
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("Failed to get VQD from any User-Agent");
}

function makeFeSignals() {
  const nowMs = Date.now();
  const startMs = nowMs - 3000;
  const events = [];
  let t = 80 + Math.floor(Math.random() * 100);
  events.push({ name: "startNewChat", delta: t });
  t += 200 + Math.floor(Math.random() * 300);
  events.push({ name: "user_submit", delta: t });
  const payload = { start: startMs, events, end: nowMs };
  return Buffer.from(JSON.stringify(payload)).toString("base64");
}

function embedImages(messages, images) {
  const out = messages.map((m) => ({ ...m }));
  const imageParts = images.map((img) => {
    const fmt = (img.format || "png").replace("jpg", "jpeg");
    const mime = `image/${fmt}`;
    return { type: "image", mimeType: mime, image: `data:${mime};base64,${img.data}` };
  });
  for (let i = out.length - 1; i >= 0; i--) {
    if (out[i].role !== "user") continue;
    const text = out[i].content;
    let parts;
    if (typeof text === "string") parts = [{ type: "text", text }];
    else if (Array.isArray(text)) parts = text.filter((p) => p && p.type === "text");
    else parts = [{ type: "text", text: String(text ?? "") }];
    out[i] = { ...out[i], content: [...parts, ...imageParts] };
    break;
  }
  return out;
}

// Async generator yielding { kind: "content" | "reasoning", token }.
export async function* chat(modelId, messages, { images } = {}) {
  const info = MODELS[modelId];
  if (!info) throw new Error(`Unknown model: ${modelId}`);
  if (images && images.length) messages = embedImages(messages, images);

  const payload = { messages, model: info.id, canUseTools: true };
  if (info.effort) payload.reasoningEffort = info.effort;

  let lastErr = null;
  for (let attempt = 0; attempt < 5; attempt++) {
    let vqd;
    let ua;
    try {
      if (challenge) {
        ua = challengeUa || nextUa();
        try {
          vqd = await solveVqd(challenge, ua);
        } catch {
          challenge = null;
          ({ vqd, ua } = await getVqd());
        }
      } else {
        ({ vqd, ua } = await getVqd());
      }
    } catch (e) {
      lastErr = e;
      await sleep(1000 * (attempt + 1));
      continue;
    }

    let resp;
    try {
      resp = await fetch(`${HOST}/duckchat/v1/chat`, {
        method: "POST",
        headers: {
          accept: "text/event-stream",
          "content-type": "application/json",
          "User-Agent": ua,
          "x-vqd-hash-1": vqd,
          Referer: "https://duck.ai/",
          Origin: "https://duck.ai",
          "x-fe-signals": makeFeSignals(),
          "x-fe-version": "serp_20250710_090702_ET-70eaca6aea2948b0bb60",
          ...cookieHeader(),
        },
        body: JSON.stringify(payload),
      });
    } catch (e) {
      lastErr = e;
      await sleep(1000 * (attempt + 1));
      continue;
    }

    storeCookies(resp);

    if (resp.status === 418 || resp.status === 429) {
      challenge = null;
      await resp.arrayBuffer().catch(() => {});
      lastErr = new Error(`HTTP ${resp.status}`);
      await sleep(2000 * (attempt + 1) + Math.random() * 3000);
      continue;
    }
    if (resp.status !== 200) {
      const text = await resp.text().catch(() => "");
      throw new Error(`HTTP ${resp.status}: ${text.slice(0, 200)}`);
    }

    const nextChallenge = resp.headers.get("x-vqd-hash-1");
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx;
        while ((idx = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, idx).replace(/\r$/, "");
          buffer = buffer.slice(idx + 1);
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (data === "[DONE]") break;
          try {
            const ev = JSON.parse(data);
            const msg = ev.message;
            if (typeof msg === "string" && msg) {
              yield { kind: ev.role === "reasoning" ? "reasoning" : "content", token: msg };
            }
          } catch {}
        }
      }
    } finally {
      try {
        reader.releaseLock();
      } catch {}
    }

    if (nextChallenge) {
      challenge = nextChallenge;
      challengeUa = ua;
    }
    return;
  }
  throw lastErr || new Error("duck.ai request failed");
}
