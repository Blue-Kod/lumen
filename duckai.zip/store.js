// Tiny JSON-file persistence, mirroring database.py's API.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DUCKAI_DB || join(__dirname, "data.json");

let data = { conversations: [], messages: [] };

function load() {
  if (existsSync(DB_PATH)) {
    try {
      const parsed = JSON.parse(readFileSync(DB_PATH, "utf-8"));
      if (parsed && Array.isArray(parsed.conversations) && Array.isArray(parsed.messages)) {
        data = parsed;
      }
    } catch (e) {
      console.error("Failed to read data file, starting empty:", e.message);
    }
  }
}

function save() {
  try {
    writeFileSync(DB_PATH, JSON.stringify(data));
  } catch (e) {
    console.error("Failed to write data file:", e.message);
  }
}

function now() {
  return Date.now() / 1000;
}

function uid() {
  return randomUUID().replace(/-/g, "");
}

function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (k in obj) out[k] = obj[k];
  return out;
}

// --- Conversations ---

export function listConversations() {
  return [...data.conversations].sort((a, b) => b.updated_at - a.updated_at);
}

export function createConversation(title = "New chat", model = "duckai/gpt56luna") {
  const t = now();
  const conv = { id: uid(), title, model, created_at: t, updated_at: t };
  data.conversations.push(conv);
  save();
  return conv;
}

export function getConversation(cid) {
  const conv = data.conversations.find((c) => c.id === cid);
  if (!conv) return null;
  const messages = data.messages
    .filter((m) => m.conversation_id === cid)
    .sort((a, b) => a.created_at - b.created_at);
  return { ...conv, messages };
}

export function updateConversation(cid, fields) {
  const conv = data.conversations.find((c) => c.id === cid);
  if (!conv) return false;
  for (const [k, v] of Object.entries(pick(fields, ["title", "model"]))) conv[k] = v;
  conv.updated_at = now();
  save();
  return true;
}

export function deleteConversation(cid) {
  const before = data.conversations.length;
  data.conversations = data.conversations.filter((c) => c.id !== cid);
  data.messages = data.messages.filter((m) => m.conversation_id !== cid);
  save();
  return data.conversations.length < before;
}

// --- Messages ---

const MSG_FIELDS = [
  "content",
  "thinking",
  "image",
  "variant_group",
  "variant_index",
  "ttft",
  "total_time",
  "tokens_per_sec",
];

export function addMessage(cid, role, content, kwargs = {}) {
  const t = now();
  const m = {
    id: uid(),
    conversation_id: cid,
    role,
    content,
    thinking: kwargs.thinking ?? null,
    image: kwargs.image ?? null,
    variant_group: kwargs.variant_group ?? null,
    variant_index: kwargs.variant_index ?? 0,
    ttft: kwargs.ttft ?? null,
    total_time: kwargs.total_time ?? null,
    tokens_per_sec: kwargs.tokens_per_sec ?? null,
    created_at: t,
  };
  data.messages.push(m);
  const conv = data.conversations.find((c) => c.id === cid);
  if (conv) conv.updated_at = t;
  save();
  return m;
}

export function updateMessage(mid, fields) {
  const m = data.messages.find((x) => x.id === mid);
  if (!m) return false;
  Object.assign(m, pick(fields, MSG_FIELDS));
  save();
  return true;
}

export function deleteMessage(mid) {
  const before = data.messages.length;
  data.messages = data.messages.filter((m) => m.id !== mid);
  save();
  return data.messages.length < before;
}

export function deleteVariantGroup(groupId) {
  const before = data.messages.length;
  data.messages = data.messages.filter((m) => m.variant_group !== groupId);
  save();
  return data.messages.length < before;
}

export function getVariants(groupId) {
  return data.messages
    .filter((m) => m.id === groupId || m.variant_group === groupId)
    .sort((a, b) => a.variant_index - b.variant_index);
}

export function getMessages(cid) {
  return data.messages
    .filter((m) => m.conversation_id === cid)
    .sort((a, b) => a.created_at - b.created_at);
}

load();
