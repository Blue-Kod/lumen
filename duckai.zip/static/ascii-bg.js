// ASCII black-hole background — monochrome, "living" characters.
// Speeds up while a response is streaming (window.AsciiHole.setActive(true)).

const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d', { alpha: false });

const CHARS = ' .,:;=+*oO0#%@';
let W = 0, H = 0, cols = 0, rows = 0;
const CELL = 10;
let dpr = Math.min(window.devicePixelRatio || 1, 2);

const state = { active: false, t: 0 };
function setActive(b) { state.active = !!b; }
window.AsciiHole = { setActive };

function resize() {
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.floor(W * dpr);
    canvas.height = Math.floor(H * dpr);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    cols = Math.ceil(W / CELL);
    rows = Math.ceil(H / CELL);
    ctx.font = `${Math.floor(CELL - 2)}px 'Space Mono', 'IBM Plex Mono', monospace`;
    ctx.textBaseline = 'middle';
}
window.addEventListener('resize', resize);
resize();

function draw() {
    ctx.fillStyle = '#101112';
    ctx.fillRect(0, 0, W, H);

    let cx = cols / 2, cy = rows / 2;
    const mainEl = document.getElementById('main');
    if (mainEl) {
        const rect = mainEl.getBoundingClientRect();
        cx = (rect.left + rect.width / 2) / CELL;
        cy = (rect.top + rect.height / 2) / CELL;
    }
    const R = Math.max(8, Math.min(cols, rows) * 0.18);  // ~2.5x overall scale
    const ring = R;                  // disk inner edge meets the photon ring
    const squash = 2.6;             // edge-on disk (thin band + wide wings, not a donut)
    const spin = state.t * (state.active ? 2.6 : 1.2);    // faster while generating

    for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
            const dx = x - cx;
            const dy = y - cy;
            const rc = Math.sqrt(dx * dx + dy * dy);   // circular (hole + photon ring)
            const ry = dy * squash;
            const rr = Math.sqrt(dx * dx + ry * ry);   // elliptical (edge-on disk)
            const ang = Math.atan2(dy, dx);

            const inner = rr - ring;
            // edge-on accretion disk: bright at the hole, fades outward into big wings
            const disk = inner > 0 ? Math.exp(-inner / (ring * 2.2)) : 0;
            // gentle differential swirl (inner spins faster)
            const swirl = spin * (1 / (0.5 + rc * 0.04));
            const wave = 0.78 + 0.22 * Math.sin(ang * 2 + swirl + state.t * 0.25);
            // full bright photon ring hugging the void (lensed disk image)
            const photo = 1 - Math.min(1, Math.abs(rc - R) / (R * 0.05));
            let inten = disk * wave * 1.6 + photo * photo * 0.9;
            // crisp black-hole shadow
            if (rc < R) inten = 0;
            // minimal living specks (no haze)
            inten += (Math.sin(x * 12.9 + y * 78.2 + state.t * 0.3) * 0.5 + 0.5) * 0.003;

            // soft, gradual falloff — smooth, no abrupt popping
            if (inten < 0.05) continue;
            inten = inten > 1 ? 1 : inten;
            const ci = Math.min(CHARS.length - 1, Math.floor(inten * (CHARS.length - 1)));
            const alpha = inten;
            ctx.fillStyle = 'rgba(232,233,227,' + alpha.toFixed(3) + ')';
            ctx.fillText(CHARS[ci], x * CELL, y * CELL + CELL / 2);
        }
    }
}

let last = 0;
function loop(now) {
    requestAnimationFrame(loop);
    if (now - last < 33) return;
    last = now;
    state.t += state.active ? 0.05 : 0.013;
    draw();
}
draw();
requestAnimationFrame(loop);
