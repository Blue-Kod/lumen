(() => {
    let models = [];
    let conversations = [];
    let currentConvId = null;
    let messages = [];
    let streaming = false;
    let attachedFile = null;
    let showReasoning = true; // user default: show reasoning header (collapsed bodies)

    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    const ICONS = {
        edit: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
        copy: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
        regenerate: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`,
        delete: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
        chevronLeft: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`,
        chevronRight: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
        chevronDown: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`,
        chevronRight12: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
        brain: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a4 4 0 0 0-4 4v1a3 3 0 0 0-3 3 3 3 0 0 0 1 5.47V16a4 4 0 0 0 8 0v-.53A3 3 0 0 0 19 10a3 3 0 0 0-3-3V6a4 4 0 0 0-4-4z"/></svg>`,
        plus: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
        trash: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
        check: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    };

    function renderMd(text) {
        if (!text) return '';
        try { return marked.parse(text, { breaks: true }); }
        catch { return text.replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
    }

    function formatMetrics(m) {
        const p = [];
        if (m.ttft != null) p.push(`${m.ttft}s TTFT`);
        if (m.total_time != null) p.push(`${m.total_time}s`);
        if (m.tokens_per_sec != null) p.push(`${m.tokens_per_sec} t/s`);
        return p.join(' · ');
    }

    function scrollToBottom() {
        const el = $('#messages');
        el.scrollTop = el.scrollHeight;
    }

    function isNearBottom() {
        const el = $('#messages');
        return el.scrollHeight - el.scrollTop - el.clientHeight < 100;
    }

    // Auto-scroll only if user is already near the bottom (so they can scroll up freely)
    function smartScroll() {
        if (isNearBottom()) scrollToBottom();
    }

    // Toggle reasoning display across all messages
    function applyReasoningToggle() {
        const on = showReasoning;
        const label = $('#reasoning-toggle-label');
        if (label) label.textContent = on ? 'Thinking' : 'Off';
        const btn = $('#reasoning-toggle');
        if (btn) btn.classList.toggle('off', !on);
        document.querySelectorAll('.thinking-block').forEach(tb => {
            tb.style.display = on ? '' : 'none';
        });
    }

    function genId() {
        return crypto.randomUUID();
    }

    // === Models ===

    async function fetchModels() {
        try {
            const r = await fetch('/v1/models');
            const d = await r.json();
            models = d.data;
            const sel = $('#model-select');
            sel.innerHTML = '';
            models.forEach(m => {
                const opt = document.createElement('option');
                opt.value = m.id;
                opt.textContent = m.name || m.id;
                sel.appendChild(opt);
            });
        } catch (e) { console.error('Failed to load models', e); }
    }

    // === Conversations ===

    async function fetchConversations() {
        try {
            const r = await fetch('/api/conversations');
            conversations = await r.json();
            // Auto-delete empty conversations
            for (const c of conversations) {
                try {
                    const msgR = await fetch(`/api/conversations/${c.id}`);
                    const msgs = await msgR.json();
                    if (msgs.length === 0 && c.id !== currentConvId) {
                        await fetch(`/api/conversations/${c.id}`, { method: 'DELETE' });
                        conversations = conversations.filter(x => x.id !== c.id);
                    }
                } catch {}
            }
            renderConversations();
            renderMessages();
        } catch (e) { console.error(e); }
    }

    function renderConversations() {
        const el = $('#conversations');
        el.innerHTML = '';
        const q = ($('#conv-search')?.value || '').trim().toLowerCase();
        const list = q ? conversations.filter(c => (c.title || '').toLowerCase().includes(q)) : conversations;
        list.forEach(c => {
            const div = document.createElement('div');
            div.className = 'conv-item' + (c.id === currentConvId ? ' active' : '');
            div.dataset.id = c.id;
            div.innerHTML = `
                <span class="title">${esc(c.title)}</span>
                <button class="rename" title="Переименовать">${ICONS.edit}</button>
                <button class="delete" title="Удалить">${ICONS.trash}</button>
            `;
            div.addEventListener('click', (e) => {
                if (e.target.closest('.delete')) {
                    e.stopPropagation();
                    const btn = e.target.closest('.delete');
                    if (btn.dataset.confirm === '1') {
                        deleteConversationAnimated(div, c.id);
                    } else {
                        btn.dataset.confirm = '1';
                        btn.innerHTML = ICONS.check;
                        btn.style.color = '#fff';
                        setTimeout(() => {
                            if (btn.dataset.confirm === '1') {
                                btn.dataset.confirm = '0';
                                btn.innerHTML = ICONS.trash;
                                btn.style.color = '';
                            }
                        }, 1500);
                    }
                    return;
                }
                if (e.target.closest('.rename')) {
                    e.stopPropagation();
                    startRename(div, c);
                    return;
                }
                selectConversation(c.id);
                if (window.matchMedia('(max-width: 820px)').matches) document.body.classList.add('nav-hidden');
            });
            el.appendChild(div);
        });
    }

    function startRename(div, c) {
        const titleEl = div.querySelector('.title');
        const oldTitle = c.title;
        titleEl.innerHTML = `<input class="rename-input" value="${esc(oldTitle)}" autofocus>`;
        const input = titleEl.querySelector('input');
        input.focus();
        input.select();
        const finish = async (save) => {
            const newTitle = save ? input.value.trim() : oldTitle;
            if (save && newTitle && newTitle !== oldTitle) {
                await fetch(`/api/conversations/${c.id}`, {
                    method: 'PUT', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title: newTitle }),
                });
                c.title = newTitle;
            }
            renderConversations();
        };
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') finish(true);
            if (e.key === 'Escape') finish(false);
        });
        input.addEventListener('blur', () => finish(true));
    }

    async function newChat() {
        // Delete current conversation if empty
        if (currentConvId && messages.length === 0) {
            await fetch(`/api/conversations/${currentConvId}`, { method: 'DELETE' });
            conversations = conversations.filter(c => c.id !== currentConvId);
        }

        const r = await fetch('/api/conversations', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: $('#model-select').value })
        });
        const c = await r.json();
        conversations.unshift(c);
        currentConvId = c.id;
        messages = [];
        renderConversations();
        renderMessages();
    }

    async function selectConversation(id) {
        currentConvId = id;
        try {
            const r = await fetch(`/api/conversations/${id}`);
            const conv = await r.json();
            // Group message rows by variant_group, keeping messages in order,
            // but merging variants of the same group into a single message.
            const rawMsgs = conv.messages || [];
            const grouped = [];
            const byId = new Map();
            for (const raw of rawMsgs) {
                if (raw.variant_group && byId.has(raw.variant_group)) {
                    const existing = byId.get(raw.variant_group);
                    existing.variants = existing.variants || [{
                        content: existing.content, thinking: existing.thinking,
                        ttft: existing.ttft, total_time: existing.total_time, tokens_per_sec: existing.tokens_per_sec,
                    }];
                    existing.variants.push({
                        content: raw.content, thinking: raw.thinking,
                        ttft: raw.ttft, total_time: raw.total_time, tokens_per_sec: raw.tokens_per_sec,
                    });
                    existing.variantIndex = existing.variants.length - 1;
                    // Show latest variant content
                    existing.content = raw.content;
                    existing.thinking = raw.thinking;
                    existing.ttft = raw.ttft;
                    existing.total_time = raw.total_time;
                    existing.tokens_per_sec = raw.tokens_per_sec;
                    continue;
                }
                const baseId = raw.variant_group || raw.id;
                const m = {
                    ...raw,
                    file: raw.image ? { type: 'image', data: raw.image } : null,
                    showThinking: false,
                    editing: false,
                    editContent: '',
                    variants: null,
                    variantIndex: 0,
                };
                byId.set(baseId, m);
                grouped.push(m);
            }
            messages = grouped;
            if (conv.model) $('#model-select').value = conv.model;
            renderConversations();
            renderMessages();
        } catch (e) { console.error(e); }
    }

    async function deleteConversationAnimated(el, id) {
        el.classList.add('conv-item-removing');
        await new Promise(r => setTimeout(r, 100));
        el.classList.add('conv-item-dust');
        await new Promise(r => setTimeout(r, 200));
        el.style.height = el.offsetHeight + 'px';
        el.offsetHeight; // force reflow
        el.style.height = '0';
        el.style.padding = '0';
        el.style.margin = '0';
        el.style.opacity = '0';
        await new Promise(r => setTimeout(r, 150));
        await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
        conversations = conversations.filter(c => c.id !== id);
        if (currentConvId === id) {
            if (conversations.length) selectConversation(conversations[0].id);
            else newChat();
        } else {
            renderConversations();
        }
    }

    // === Messages ===

    function renderMessages() {
        const el = $('#messages');
        el.innerHTML = '';
        if (messages.length === 0) {
            el.innerHTML = `
                <div class="empty-state">
                    <div class="empty-content">
                        <h2>Чем могу помочь?</h2>
                        <div class="empty-examples">
                            <button class="empty-example" data-text="Объясни квантовые вычисления простыми словами">Объясни квантовые вычисления простыми словами</button>
                            <button class="empty-example" data-text="Напиши короткую историю о коте-программисте">Напиши короткую историю о коте-программисте</button>
                            <button class="empty-example" data-text="Сравни Python и Rust для веб-разработки">Сравни Python и Rust для веб-разработки</button>
                            <button class="empty-example" data-text="Помоги написать функцию для сортировки слиянием">Помоги написать функцию для сортировки слиянием</button>
                        </div>
                    </div>
                </div>
            `;
            el.querySelectorAll('.empty-example').forEach(btn => {
                btn.addEventListener('click', () => {
                    $('#input').value = btn.dataset.text;
                    updateSendBtn();
                    sendMessage();
                });
            });
            return;
        }
        messages.forEach((m, idx) => {
            el.appendChild(createMessageEl(m, idx));
        });
        applyReasoningToggle();
        scrollToBottom();
    }

    function createMessageEl(m, idx) {
        const div = document.createElement('div');
        div.className = 'msg ' + m.role;
        div.dataset.idx = idx;

        // Thinking block
        if (m.thinking) {
            const tb = document.createElement('div');
            tb.className = 'thinking-block';
            tb.innerHTML = `
                <div class="thinking-header">
                    <span class="thinking-label">${ICONS.brain} Размышления</span>
                    <span class="thinking-toggle">${m.showThinking ? ICONS.chevronDown : ICONS.chevronRight12}</span>
                </div>
                <div class="thinking-content" style="display:block">${renderMd(m.thinking)}</div>
            `;
            div.appendChild(tb);
        }

        // Content
        if (m.editing) {
            const editDiv = document.createElement('div');
            editDiv.className = 'edit-mode';
            editDiv.innerHTML = `
                <textarea class="edit-textarea">${esc(m.content)}</textarea>
                <div class="edit-actions">
                    <button class="btn-save">Сохранить и отправить</button>
                    <button class="btn-cancel">Отмена</button>
                </div>
            `;
            div.appendChild(editDiv);
        } else {
            if (m.file && m.file.type === 'image') {
                const imgWrap = document.createElement('div');
                imgWrap.className = 'msg-image';
                const img = document.createElement('img');
                img.src = m.file.data;
                img.addEventListener('click', () => showFullImage(m.file.data));
                imgWrap.appendChild(img);
                div.appendChild(imgWrap);
            }

            const content = document.createElement('div');
            content.className = 'msg-content';
            content.innerHTML = renderMd(m.content);
            div.appendChild(content);

            // User actions inline
            if (m.role === 'user') {
                const actions = document.createElement('div');
                actions.className = 'msg-actions-inline';

                const editBtn = document.createElement('button');
                editBtn.innerHTML = ICONS.edit;
                editBtn.title = 'Редактировать';
                actions.appendChild(editBtn);

                const copyBtn = document.createElement('button');
                copyBtn.innerHTML = ICONS.copy;
                copyBtn.title = 'Копировать';
                actions.appendChild(copyBtn);

                div.appendChild(actions);
            }
        }

        // Metrics + Actions (merged row)
        if (m.role === 'assistant' && (m.ttft != null || m.total_time != null || m.tokens_per_sec != null || m.variants)) {
            const met = document.createElement('div');
            met.className = 'msg-metrics';
            const metText = document.createElement('span');
            metText.textContent = formatMetrics(m);
            met.appendChild(metText);

            const actions = document.createElement('div');
            actions.className = 'msg-actions';

            if (m.variants && m.variants.length > 1) {
                const prevBtn = document.createElement('button');
                prevBtn.innerHTML = ICONS.chevronLeft;
                prevBtn.title = 'Предыдущий вариант';
                prevBtn.disabled = m.variantIndex === 0;
                actions.appendChild(prevBtn);
                const countSpan = document.createElement('span');
                countSpan.className = 'variant-count';
                countSpan.textContent = `${m.variantIndex + 1}/${m.variants.length}`;
                actions.appendChild(countSpan);
                const nextBtn = document.createElement('button');
                nextBtn.innerHTML = ICONS.chevronRight;
                nextBtn.title = 'Следующий вариант';
                nextBtn.disabled = m.variantIndex === m.variants.length - 1;
                actions.appendChild(nextBtn);
            }

            const regenBtn = document.createElement('button');
            regenBtn.innerHTML = ICONS.regenerate;
            regenBtn.title = 'Перегенерировать';
            regenBtn.disabled = streaming;
            actions.appendChild(regenBtn);

            const copyBtn = document.createElement('button');
            copyBtn.innerHTML = ICONS.copy;
            copyBtn.title = 'Копировать';
            actions.appendChild(copyBtn);

            const delBtn = document.createElement('button');
            delBtn.innerHTML = ICONS.delete;
            delBtn.title = 'Удалить';
            actions.appendChild(delBtn);

            met.appendChild(actions);
            div.appendChild(met);
        } else if (m.role === 'assistant') {
            const actions = document.createElement('div');
            actions.className = 'msg-actions';
            actions.style.marginTop = '10px';

            if (m.variants && m.variants.length > 1) {
                const prevBtn = document.createElement('button');
                prevBtn.innerHTML = ICONS.chevronLeft;
                prevBtn.title = 'Предыдущий вариант';
                prevBtn.disabled = m.variantIndex === 0;
                actions.appendChild(prevBtn);
                const countSpan = document.createElement('span');
                countSpan.className = 'variant-count';
                countSpan.textContent = `${m.variantIndex + 1}/${m.variants.length}`;
                actions.appendChild(countSpan);
                const nextBtn = document.createElement('button');
                nextBtn.innerHTML = ICONS.chevronRight;
                nextBtn.title = 'Следующий вариант';
                nextBtn.disabled = m.variantIndex === m.variants.length - 1;
                actions.appendChild(nextBtn);
            }

            const regenBtn = document.createElement('button');
            regenBtn.innerHTML = ICONS.regenerate;
            regenBtn.title = 'Перегенерировать';
            regenBtn.disabled = streaming;
            actions.appendChild(regenBtn);

            const copyBtn = document.createElement('button');
            copyBtn.innerHTML = ICONS.copy;
            copyBtn.title = 'Копировать';
            actions.appendChild(copyBtn);

            const delBtn = document.createElement('button');
            delBtn.innerHTML = ICONS.delete;
            delBtn.title = 'Удалить';
            actions.appendChild(delBtn);

            div.appendChild(actions);
        }

        wireMessage(div, m);
        return div;
    }

    // Wires interactive handlers for a message element. Used both when a message
    // element is freshly created AND when its innerHTML is replaced in place
    // (innerHTML copy drops listeners, so they must be re-attached).
    function wireMessage(div, m) {
        const th = div.querySelector('.thinking-header');
        if (th) {
            th.addEventListener('click', () => {
                m.showThinking = !m.showThinking;
                const tc = div.querySelector('.thinking-content');
                const tg = div.querySelector('.thinking-toggle');
                if (tc) tc.style.display = m.showThinking ? 'block' : 'none';
                if (tg) tg.innerHTML = m.showThinking ? ICONS.chevronDown : ICONS.chevronRight12;
            });
        }
        const editBtn = div.querySelector('.msg-actions-inline button[title="Редактировать"]');
        if (editBtn) editBtn.addEventListener('click', () => startEdit(m));
        div.querySelectorAll('button[title="Копировать"]').forEach(b => b.addEventListener('click', () => copyMessage(m)));
        const regenBtn = div.querySelector('button[title="Перегенерировать"]');
        if (regenBtn) { regenBtn.disabled = streaming; regenBtn.addEventListener('click', () => regenerate(m)); }
        const delBtn = div.querySelector('button[title="Удалить"]');
        if (delBtn) delBtn.addEventListener('click', (e) => deleteMessage(m, e.currentTarget));
        const prevBtn = div.querySelector('button[title="Предыдущий вариант"]');
        if (prevBtn) prevBtn.addEventListener('click', () => switchVariant(m, -1));
        const nextBtn = div.querySelector('button[title="Следующий вариант"]');
        if (nextBtn) nextBtn.addEventListener('click', () => switchVariant(m, 1));
    }

    function updateMessageEl(m) {
        const el = $(`.msg[data-idx="${messages.indexOf(m)}"]`);
        if (!el) return;
        const newEl = createMessageEl(m, messages.indexOf(m));
        el.replaceWith(newEl);
        scrollToBottom();
    }

    // === Send / Stream ===

    async function sendMessage() {
        const text = $('#input').value.trim();
        if (!text && !attachedFile) return;
        if (streaming) return;

        // Create conversation if none exists
        if (!currentConvId) {
            const r = await fetch('/api/conversations', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: $('#model-select').value })
            });
            const c = await r.json();
            conversations.unshift(c);
            currentConvId = c.id;
            renderConversations();
        }

        const userMsg = {
            id: genId(), role: 'user', content: text, file: attachedFile,
            showThinking: false, editing: false, editContent: '',
            variants: null, variantIndex: 0,
        };
        messages.push(userMsg);

        await fetch(`/api/conversations/${currentConvId}/msg`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ role: 'user', content: text, file: attachedFile }),
        });

        $('#input').value = '';
        $('#input').style.height = 'auto';
        document.body.classList.remove('typing');
        attachedFile = null;
        $('#file-preview').style.display = 'none';
        updateSendBtn();
        const messagesEl = $('#messages');
        const empty = messagesEl.querySelector('.empty-state');
        if (empty) empty.remove();
        messagesEl.appendChild(createMessageEl(userMsg, messages.length - 1));
        scrollToBottom();
        await streamResponse();
    }

    async function streamResponse() {
        streaming = true;
        updateSendBtn();
        if (window.AsciiHole) window.AsciiHole.setActive(true);
        document.body.classList.add('generating');

        const assistantMsg = {
            id: genId(), role: 'assistant', content: '',
            thinking: null, showThinking: false,
            editing: false, editContent: '',
            variants: null, variantIndex: 0,
            ttft: null, total_time: null, tokens_per_sec: null,
        };
        messages.push(assistantMsg);
        const msgIdx = messages.length - 1;

        const model = $('#model-select').value;
        const convMessages = messages.filter(m => m.role === 'user').map(m => {
            return { role: 'user', content: m.content };
        });

        // Collect images from user messages
        const allImages = [];
        messages.filter(m => m.role === 'user' && m.file && m.file.type === 'image').forEach(m => {
            const dataUrl = m.file.data;
            const base64 = dataUrl.split(',')[1];
            const mime = dataUrl.split(';')[0].split(':')[1] || 'image/jpeg';
            const format = mime.split('/')[1] || 'jpeg';
            allImages.push({ data: base64, format: format });
        });

        // Create streaming indicator
        const streamDiv = document.createElement('div');
        streamDiv.className = 'msg assistant';
        streamDiv.id = 'streaming-msg';
        streamDiv.innerHTML = `
            <div class="msg-content" id="stream-content"><span class="typing-dots"><span>.</span><span>.</span><span>.</span></span></div>
        `;
        $('#messages').appendChild(streamDiv);
        scrollToBottom();

        let content = '';
        let thinking = '';
        let thinkingActive = false;

        try {
            const r = await fetch('/v1/chat/completions', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model, messages: convMessages, stream: true, images: allImages.length > 0 ? allImages : undefined }),
            });
            const reader = r.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();
                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    const data = line.slice(6).trim();
                    if (data === '[DONE]') continue;
                    try {
                        const j = JSON.parse(data);
                        const delta = j.choices?.[0]?.delta;
                        if (delta?.reasoning) {
                            thinking += delta.reasoning;
                            thinkingActive = true;
                        }
                        if (delta?.content) {
                            if (thinkingActive) thinkingActive = false;
                            content += delta.content;
                        }
                        const el = $('#stream-content');
                        if (el) {
                            let html = '';
                            if (thinking) {
                                html = `
                                    <div class="thinking-block">
                                        <div class="thinking-header">
                                            <span class="thinking-label">${ICONS.brain} Размышления</span>
                                            <span class="thinking-toggle">${ICONS.chevronRight12}</span>
                                        </div>
                                        <div class="thinking-content" style="display:none">${renderMd(thinking)}</div>
                                    </div>
                                `;
                                el.querySelector('.thinking-header')?.addEventListener('click', () => {
                                    const tc = el.querySelector('.thinking-content');
                                    const tg = el.querySelector('.thinking-toggle');
                                    if (tc) {
                                        const show = tc.style.display === 'none';
                                        tc.style.display = show ? 'block' : 'none';
                                        tg.innerHTML = show ? ICONS.chevronDown : ICONS.chevronRight12;
                                    }
                                });
                            }
                            if (content) html += renderMd(content);
                            // Only replace the typing indicator once we actually have text,
                            // otherwise the empty first SSE chunk ("role") would wipe the dots.
                            if (html) {
                                el.innerHTML = html;
                            }
                            smartScroll();
                        }
                        if (j.metrics) {
                            assistantMsg.ttft = j.metrics.ttft;
                            assistantMsg.total_time = j.metrics.total_time;
                            assistantMsg.tokens_per_sec = j.metrics.tokens_per_sec;
                        }
                    } catch {}
                }
            }
        } catch (e) {
            content += `\n\n[Error: ${e.message}]`;
        }

        assistantMsg.content = content || '—';
        assistantMsg.thinking = thinking || null;
        streaming = false;
        if (window.AsciiHole) window.AsciiHole.setActive(false);
        document.body.classList.remove('generating');
        updateSendBtn();

        // Finalize the streaming indicator in place (same DOM node) so the
        // message never blinks/flickers when generation finishes.
        const streamEl = $('#streaming-msg');
        if (streamEl) {
            const idx = messages.indexOf(assistantMsg) >= 0 ? messages.indexOf(assistantMsg) : messages.length - 1;
            const finalEl = createMessageEl(assistantMsg, idx);
            streamEl.removeAttribute('id');
            streamEl.dataset.idx = finalEl.dataset.idx;
            streamEl.innerHTML = finalEl.innerHTML;
            finalEl.remove();
            wireMessage(streamEl, assistantMsg);
        }
        scrollToBottom();

        // Save to DB
        try {
            const r = await fetch(`/api/conversations/${currentConvId}/msg`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    role: 'assistant', content: assistantMsg.content,
                    thinking: assistantMsg.thinking,
                    ttft: assistantMsg.ttft, total_time: assistantMsg.total_time,
                    tokens_per_sec: assistantMsg.tokens_per_sec,
                }),
            });
            if (r.ok) {
                const saved = await r.json();
                if (saved && saved.id) assistantMsg.id = saved.id;
            }
        } catch (e) { console.error(e); }

        await autoTitle();
    }

    async function autoTitle() {
        if (messages.length !== 2) return;
        const first = messages[0];
        if (first.role !== 'user') return;
        const title = first.content.slice(0, 60).replace(/\n/g, ' ');

        await fetch(`/api/conversations/${currentConvId}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title }),
        });
        const conv = conversations.find(c => c.id === currentConvId);
        if (conv) conv.title = title;
        renderConversations();
    }

    // === Regenerate ===

    async function regenerate(m) {
        if (streaming) return;
        const idx = messages.indexOf(m);
        if (idx < 0) return;

        const userMsgs = messages.slice(0, idx).filter(x => x.role === 'user');
        const convMessages = userMsgs.map(msg => ({ role: 'user', content: msg.content }));

        // Collect images
        const allImages = [];
        userMsgs.filter(msg => msg.file && msg.file.type === 'image').forEach(msg => {
            const dataUrl = msg.file.data;
            const base64 = dataUrl.split(',')[1];
            const mime = dataUrl.split(';')[0].split(':')[1] || 'image/jpeg';
            const format = mime.split('/')[1] || 'jpeg';
            allImages.push({ data: base64, format: format });
        });

        streaming = true;
        document.body.classList.add('generating');
        if (window.AsciiHole) window.AsciiHole.setActive(true);
        updateSendBtn();

        const existingVariants = m.variants || [{
            content: m.content, thinking: m.thinking,
            ttft: m.ttft, total_time: m.total_time, tokens_per_sec: m.tokens_per_sec,
        }];
        const variantIndex = existingVariants.length;

        // Replace the current message element with streaming indicator
        const currentEl = $(`.msg[data-idx="${idx}"]`);
        if (currentEl) {
            currentEl.innerHTML = `
                <div class="msg-content" id="stream-content"><span class="typing-dots"><span>.</span><span>.</span><span>.</span></span></div>
            `;
        }
        scrollToBottom();

        let content = '';
        let thinking = null;
        let thinkingActive = false;
        let ttft = null;
        let totalStart = performance.now();

        try {
            const r = await fetch('/v1/chat/completions', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: $('#model-select').value, messages: convMessages, stream: true, images: allImages.length > 0 ? allImages : undefined }),
            });
            const reader = r.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();
                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    const data = line.slice(6).trim();
                    if (data === '[DONE]') continue;
                    try {
                        const j = JSON.parse(data);
                        const delta = j.choices?.[0]?.delta;

                        if (j.ttft != null) ttft = j.ttft;
                        if (j.total_time != null) totalStart = performance.now() - j.total_time * 1000;

                        if (delta?.reasoning && !thinkingActive) {
                            thinkingActive = true;
                        }
                        if (delta?.reasoning) {
                            thinking = (thinking || '') + delta.reasoning;
                        }
                        if (delta?.content) {
                            if (thinkingActive) thinkingActive = false;
                            content += delta.content;
                        }

                        const el = $('#stream-content');
                        if (el) {
                            let html = '';
                            if (thinking) {
                                html = `
                                    <div class="thinking-block">
                                        <div class="thinking-header">
                                            <span class="thinking-label">${ICONS.brain} Размышления</span>
                                            <span class="thinking-toggle">${ICONS.chevronRight12}</span>
                                        </div>
                                        <div class="thinking-content" style="display:none">${renderMd(thinking)}</div>
                                    </div>
                                `;
                                el.querySelector('.thinking-header')?.addEventListener('click', () => {
                                    const tc = el.querySelector('.thinking-content');
                                    const tg = el.querySelector('.thinking-toggle');
                                    if (tc) {
                                        const show = tc.style.display === 'none';
                                        tc.style.display = show ? 'block' : 'none';
                                        tg.innerHTML = show ? ICONS.chevronDown : ICONS.chevronRight12;
                                    }
                                });
                            }
                            if (content) html += renderMd(content);
                            if (html) {
                                el.innerHTML = html;
                            }
                        }
                        smartScroll();
                    } catch {}
                }
            }
        } catch (e) {
            content += `\n\n[Error: ${e.message}]`;
        }

        const total_time = (performance.now() - totalStart) / 1000;
        const tokensPerSec = content.length > 0 ? Math.round(content.split(/\s+/).length / total_time) : 0;

        existingVariants.push({
            content, thinking, ttft, total_time, tokens_per_sec: tokensPerSec,
        });

        messages[idx] = {
            ...m, content: content || '—', thinking,
            variants: existingVariants, variantIndex: existingVariants.length - 1,
            ttft, total_time, tokens_per_sec: tokensPerSec,
        };

        streaming = false;
        if (window.AsciiHole) window.AsciiHole.setActive(false);
        document.body.classList.remove('generating');
        updateSendBtn();

        // Finalize the regenerated message in place (no full re-render -> no blink).
        const finalEl = createMessageEl(messages[idx], idx);
        if (currentEl) {
            currentEl.className = finalEl.className;
            currentEl.dataset.idx = finalEl.dataset.idx;
            currentEl.innerHTML = finalEl.innerHTML;
            wireMessage(currentEl, messages[idx]);
        } else {
            renderMessages();
        }
        finalEl.remove();
        scrollToBottom();

        await fetch(`/api/conversations/${currentConvId}/msg`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                role: 'assistant', content, thinking,
                variant_group: m.id, variant_index: variantIndex,
                ttft, total_time, tokens_per_sec: tokensPerSec,
            }),
        });
    }

    function switchVariant(m, dir) {
        if (!m.variants) return;
        const newIdx = m.variantIndex + dir;
        if (newIdx < 0 || newIdx >= m.variants.length) return;
        m.variantIndex = newIdx;
        const v = m.variants[newIdx];
        m.content = v.content;
        m.thinking = v.thinking;
        m.ttft = v.ttft;
        m.total_time = v.total_time;
        m.tokens_per_sec = v.tokens_per_sec;
        updateMessageEl(m);
    }

    // === Edit ===

    function startEdit(m) {
        m.editing = true;
        m.editContent = m.content;
        updateMessageEl(m);
    }

    function cancelEdit(m) {
        m.editing = false;
        updateMessageEl(m);
    }

    async function saveEdit(m) {
        const textarea = $(`.msg[data-idx="${messages.indexOf(m)}"] .edit-textarea`);
        if (!textarea) return;
        const newContent = textarea.value.trim();
        if (!newContent) return;
        m.content = newContent;
        m.editing = false;

        await fetch(`/api/conversations/${currentConvId}/msg/${m.id}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: newContent }),
        });

        if (m.role === 'assistant') {
            updateMessageEl(m);
            return;
        }

        const afterIdx = messages.indexOf(m);
        const toDelete = messages.slice(afterIdx + 1).filter(x => x.role === 'assistant');
        for (const d of toDelete) {
            await fetch(`/api/conversations/${currentConvId}/msg/${d.id}`, { method: 'DELETE' });
        }
        messages = messages.slice(0, afterIdx + 1);
        renderMessages();
        await streamResponse();
    }

    // === Copy / Delete ===

    let _toastTimer = null;
    function showToast(text) {
        let t = $('#toast');
        if (!t) {
            t = document.createElement('div');
            t.id = 'toast';
            t.className = 'toast';
            document.body.appendChild(t);
        }
        t.textContent = text;
        // force reflow so the transition runs on each call
        void t.offsetWidth;
        t.classList.add('show');
        clearTimeout(_toastTimer);
        _toastTimer = setTimeout(() => t.classList.remove('show'), 1400);
    }

    async function copyMessage(m) {
        try {
            await navigator.clipboard.writeText(m.content);
        } catch {
            const ta = document.createElement('textarea');
            ta.value = m.content;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); } catch {}
            ta.remove();
        }
        showToast('Скопировано');
    }

    async function deleteMessage(m, btn) {
        if (btn && btn.dataset.confirm !== '1') {
            btn.dataset.confirm = '1';
            btn.innerHTML = ICONS.check;
            btn.style.color = '#f44';
            setTimeout(() => {
                if (btn.dataset.confirm === '1') {
                    btn.dataset.confirm = '0';
                    btn.innerHTML = ICONS.delete;
                    btn.style.color = '';
                }
            }, 1500);
            return;
        }
        if (btn) {
            btn.dataset.confirm = '0';
            btn.innerHTML = ICONS.delete;
            btn.style.color = '';
        }
        await fetch(`/api/conversations/${currentConvId}/msg/${m.id}`, { method: 'DELETE' });
        messages = messages.filter(x => x !== m);
        renderMessages();
    }

    // === File Upload ===

    function handleFileUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            const isImage = file.type.startsWith('image/');
            if (isImage) {
                attachedFile = { type: 'image', data: ev.target.result, name: file.name };
                $('#preview-img').src = ev.target.result;
                $('#file-img-preview').style.display = 'block';
                $('#file-text-preview').style.display = 'none';
            } else {
                attachedFile = { type: 'text', data: ev.target.result, name: file.name };
                $('#file-name').textContent = file.name;
                $('#file-text-preview').style.display = 'inline-flex';
                $('#file-img-preview').style.display = 'none';
            }
            $('#file-preview').style.display = 'block';
            updateSendBtn();
        };
        if (file.type.startsWith('image/')) {
            reader.readAsDataURL(file);
        } else {
            reader.readAsText(file);
        }
        e.target.value = '';
    }

    function showFullImage(url) {
        const modal = $('#image-modal');
        $('#modal-img').src = url;
        modal.style.display = 'flex';
    }

    // === Helpers ===

    function esc(s) {
        const d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function updateSendBtn() {
        const btn = $('#send-btn');
        const text = $('#input').value.trim();
        const hasContent = text || attachedFile;
        btn.disabled = streaming || !hasContent;
        if (!hasContent) document.body.classList.remove('typing');
    }

    function autoResize(el) {
        el.style.height = 'auto';
        el.style.height = Math.min(el.scrollHeight, 200) + 'px';
    }

    // === Init ===

    async function init() {
        await fetchModels();
        renderMessages();
        await fetchConversations();
        // Don't create chat until first message

        $('#new-chat-btn').addEventListener('click', newChat);
        const sbToggle = $('#sidebar-toggle');
        if (sbToggle) sbToggle.addEventListener('click', () => document.body.classList.toggle('nav-hidden'));
        const backdrop = $('#nav-backdrop');
        if (backdrop) backdrop.addEventListener('click', () => document.body.classList.add('nav-hidden'));
        if (window.matchMedia('(max-width: 820px)').matches) document.body.classList.add('nav-hidden');
        window.addEventListener('resize', () => {
            if (!window.matchMedia('(max-width: 820px)').matches) document.body.classList.remove('nav-hidden');
        });
        const rt = $('#reasoning-toggle');
        if (rt) rt.addEventListener('click', () => { showReasoning = !showReasoning; applyReasoningToggle(); });
        const convSearch = $('#conv-search');
        if (convSearch) convSearch.addEventListener('input', renderConversations);
        applyReasoningToggle();
        $('#model-select').addEventListener('change', async () => {
            if (currentConvId) {
                await fetch(`/api/conversations/${currentConvId}`, {
                    method: 'PUT', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model: $('#model-select').value }),
                });
            }
        });

        const input = $('#input');
        input.addEventListener('input', () => {
            autoResize(input);
            updateSendBtn();
            document.body.classList.toggle('typing', input.value.trim().length > 0);
        });
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        $('#send-btn').addEventListener('click', sendMessage);
        $('#file-input').addEventListener('change', handleFileUpload);
        $('#remove-file').addEventListener('click', () => {
            attachedFile = null;
            $('#file-preview').style.display = 'none';
            updateSendBtn();
        });
        $('#remove-img').addEventListener('click', () => {
            attachedFile = null;
            $('#file-preview').style.display = 'none';
            updateSendBtn();
        });
        $('#expand-img').addEventListener('click', () => {
            if (attachedFile && attachedFile.type === 'image') {
                showFullImage(attachedFile.data);
            }
        });

        $('#image-modal').addEventListener('click', () => {
            $('#image-modal').style.display = 'none';
        });
    }

    init();
})();
