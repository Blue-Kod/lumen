// Minimal pure Node.js backend for duck.ai.
// - OpenAI-compatible /v1/models and /v1/chat/completions (SSE streaming)
// - Conversation/message persistence API used by the bundled web UI
// - Serves the static UI from ./static
import http from "node:http";
import { readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";
import { chat, MODELS } from "./duckai.js";
import * as store from "./store.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const STATIC_DIR = join(__dirname, "static");
const PORT = Number(process.env.PORT || 8000);
const HOST = process.env.HOST || "0.0.0.0";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Origin": "*",
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (c) => {
      body += c;
      if (body.length > 64 * 1024 * 1024) {
        reject(new Error("payload too large"));
        req.destroy();
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

async function readJson(req) {
  const body = await readBody(req);
  if (!body) return {};
  return JSON.parse(body);
}

function listModels() {
  return Object.entries(MODELS).map(([key, info]) => ({
    id: `duckai/${key}`,
    object: "model",
    created: 0,
    owned_by: "duckai",
    name: info.name,
    description: info.desc,
  }));
}

function parseModel(model) {
  if (typeof model === "string" && model.includes("/")) {
    const idx = model.indexOf("/");
    return { prefix: model.slice(0, idx), modelId: model.slice(idx + 1) };
  }
  return { prefix: "duckai", modelId: model };
}

// --- OpenAI-compatible chat ---

async function handleChatCompletions(req, res) {
  let body;
  try {
    body = await readJson(req);
  } catch {
    return sendJson(res, 400, { error: { message: "Invalid JSON body" } });
  }

  const { prefix, modelId } = parseModel(body.model);
  if (prefix !== "duckai") {
    return sendJson(res, 404, { error: { message: `Unknown provider: ${prefix}` } });
  }
  if (!MODELS[modelId]) {
    return sendJson(res, 404, { error: { message: `Unknown model: ${body.model}` } });
  }

  const messages = (body.messages || []).map((m) => ({ role: m.role, content: m.content }));
  const images = body.images || null;
  const t0 = Date.now();

  if (!body.stream) {
    const parts = [];
    const reasoningParts = [];
    let ttft = null;
    let tokenCount = 0;
    try {
      for await (const { kind, token } of chat(modelId, messages, { images })) {
        if (ttft === null) ttft = (Date.now() - t0) / 1000;
        tokenCount++;
        (kind === "reasoning" ? reasoningParts : parts).push(token);
      }
    } catch (e) {
      return sendJson(res, 502, { error: { message: String(e.message || e) } });
    }
    const content = parts.join("");
    const reasoning = reasoningParts.join("") || null;
    const totalTime = (Date.now() - t0) / 1000;
    const tokenEst = content.split(/\s+/).filter(Boolean).length;
    return sendJson(res, 200, {
      id: `chatcmpl-${randomUUID().replace(/-/g, "").slice(0, 12)}`,
      object: "chat.completion",
      created: Math.floor(Date.now() / 1000),
      model: body.model,
      choices: [
        {
          index: 0,
          message: { role: "assistant", content, reasoning_content: reasoning },
          finish_reason: "stop",
        },
      ],
      usage: { prompt_tokens: 0, completion_tokens: tokenEst, total_tokens: tokenEst },
      metrics: {
        ttft: ttft === null ? null : Number(ttft.toFixed(3)),
        total_time: Number(totalTime.toFixed(3)),
        tokens_per_sec: totalTime > 0 ? Number((tokenCount / totalTime).toFixed(1)) : 0,
      },
    });
  }

  // Streaming (SSE)
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "Access-Control-Allow-Origin": "*",
  });

  const chatId = `chatcmpl-${randomUUID().replace(/-/g, "").slice(0, 12)}`;
  const created = Math.floor(Date.now() / 1000);

  const writeChunk = (delta, finishReason = null, extra = {}) => {
    if (res.writableEnded) return;
    const chunk = {
      id: chatId,
      object: "chat.completion.chunk",
      created,
      model: modelId,
      choices: [{ index: 0, delta, finish_reason: finishReason }],
      ...extra,
    };
    res.write(`data: ${JSON.stringify(chunk)}\n\n`);
  };

  writeChunk({ role: "assistant", content: "" });

  let ttft = null;
  let tokenCount = 0;
  let aborted = false;
  res.on("close", () => {
    aborted = true;
  });

  try {
    for await (const { kind, token } of chat(modelId, messages, { images })) {
      if (aborted) return;
      if (ttft === null) ttft = (Date.now() - t0) / 1000;
      tokenCount++;
      writeChunk(kind === "reasoning" ? { reasoning: token } : { content: token });
    }
  } catch (e) {
    writeChunk({ content: `\n\n[Error: ${e.message || e}]` }, "stop");
  }

  const totalTime = (Date.now() - t0) / 1000;
  writeChunk({}, "stop", {
    metrics: {
      ttft: ttft === null ? null : Number(ttft.toFixed(3)),
      total_time: Number(totalTime.toFixed(3)),
      tokens_per_sec: totalTime > 0 ? Number((tokenCount / totalTime).toFixed(1)) : 0,
    },
  });
  if (!res.writableEnded) res.write("data: [DONE]\n\n");
  if (!res.writableEnded) res.end();
}

// --- Conversations API ---

async function handleApi(req, res, pathname, method) {
  let m;

  if (pathname === "/api/conversations") {
    if (method === "GET") return sendJson(res, 200, store.listConversations());
    if (method === "POST") {
      const body = await readJson(req).catch(() => ({}));
      return sendJson(
        res,
        200,
        store.createConversation(body.title || "New chat", body.model || "duckai/gpt56luna")
      );
    }
    return sendJson(res, 405, { error: "method not allowed" });
  }

  if ((m = pathname.match(/^\/api\/conversations\/([^/]+)$/))) {
    const cid = decodeURIComponent(m[1]);
    if (method === "GET") {
      const conv = store.getConversation(cid);
      if (!conv) return sendJson(res, 404, { detail: "Conversation not found" });
      return sendJson(res, 200, conv);
    }
    if (method === "PUT") {
      const body = await readJson(req).catch(() => ({}));
      const ok = store.updateConversation(cid, body);
      if (!ok) return sendJson(res, 404, { detail: "Conversation not found" });
      return sendJson(res, 200, { ok: true });
    }
    if (method === "DELETE") {
      const ok = store.deleteConversation(cid);
      if (!ok) return sendJson(res, 404, { detail: "Conversation not found" });
      return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 405, { error: "method not allowed" });
  }

  if ((m = pathname.match(/^\/api\/conversations\/([^/]+)\/msg$/))) {
    const cid = decodeURIComponent(m[1]);
    if (method === "POST") {
      const body = await readJson(req).catch(() => ({}));
      let image = body.image ?? null;
      if (body.file && body.file.type === "image") image = body.file.data;
      const kwargs = {};
      for (const k of ["thinking", "variant_group", "variant_index", "ttft", "total_time", "tokens_per_sec"]) {
        if (k in body) kwargs[k] = body[k];
      }
      kwargs.image = image;
      const msg = store.addMessage(cid, body.role || "user", body.content || "", kwargs);
      return sendJson(res, 200, msg);
    }
    return sendJson(res, 405, { error: "method not allowed" });
  }

  if ((m = pathname.match(/^\/api\/conversations\/([^/]+)\/msg\/([^/]+)\/variants$/))) {
    const mid = decodeURIComponent(m[2]);
    if (method === "GET") return sendJson(res, 200, store.getVariants(mid));
    return sendJson(res, 405, { error: "method not allowed" });
  }

  if ((m = pathname.match(/^\/api\/conversations\/([^/]+)\/msg\/([^/]+)$/))) {
    const mid = decodeURIComponent(m[2]);
    if (method === "PUT") {
      const body = await readJson(req).catch(() => ({}));
      const ok = store.updateMessage(mid, body);
      if (!ok) return sendJson(res, 404, { detail: "Message not found" });
      return sendJson(res, 200, { ok: true });
    }
    if (method === "DELETE") {
      const ok = store.deleteMessage(mid);
      if (!ok) return sendJson(res, 404, { detail: "Message not found" });
      return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 405, { error: "method not allowed" });
  }

  return sendJson(res, 404, { detail: "Not found" });
}

// --- Static files ---

async function serveStatic(res, relPath) {
  const safe = normalize(relPath).replace(/^(\.\.[/\\])+/, "");
  const filePath = join(STATIC_DIR, safe);
  if (!filePath.startsWith(STATIC_DIR)) return sendJson(res, 403, { detail: "Forbidden" });
  try {
    const buf = await readFile(filePath);
    const ext = filePath.slice(filePath.lastIndexOf("."));
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Content-Length": buf.length,
    });
    res.end(buf);
  } catch {
    sendJson(res, 404, { detail: "Not found" });
  }
}

// --- Server ---

const server = http.createServer(async (req, res) => {
  const { pathname } = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const method = req.method || "GET";

  if (method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type,Authorization",
    });
    return res.end();
  }

  try {
    if (pathname === "/" || pathname === "/index.html") return await serveStatic(res, "index.html");
    if (pathname.startsWith("/static/")) return await serveStatic(res, pathname.slice("/static/".length));
    if (pathname === "/v1/models" && method === "GET") return sendJson(res, 200, { object: "list", data: listModels() });
    if (pathname === "/v1/chat/completions" && method === "POST") return await handleChatCompletions(req, res);
    if (pathname.startsWith("/api/")) return await handleApi(req, res, pathname, method);
    return sendJson(res, 404, { detail: "Not found" });
  } catch (e) {
    console.error(e);
    if (!res.headersSent) sendJson(res, 500, { detail: String(e.message || e) });
    else if (!res.writableEnded) res.end();
  }
});

server.listen(PORT, HOST, () => {
  console.log(`duckai-node listening on http://${HOST}:${PORT}`);
});
