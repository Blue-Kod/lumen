// Solves Duck.ai's `x-vqd-hash-1` challenge by executing its script inside jsdom
// and hashing the collected client fingerprints. Port of duckai_vqd.js.
import { JSDOM } from "jsdom";
import { createHash } from "node:crypto";

function makeDom() {
  const dom = new JSDOM(
    `<iframe id="jsa" sandbox="allow-scripts allow-same-origin" srcdoc="<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Security-Policy"; content="default-src 'none'; script-src 'unsafe-inline'">
</head><body></body></iframe>" style="position: absolute; left: -9999px; top: -9999px;"></iframe>`,
    { runScripts: "dangerously" }
  );
  dom.window.top.__DDG_BE_VERSION__ = 1;
  dom.window.top.__DDG_FE_CHAT_HASH__ = 1;
  const jsa = dom.window.top.document.querySelector("#jsa");
  const contentDoc = jsa.contentDocument || jsa.contentWindow.document;
  const meta = contentDoc.createElement("meta");
  meta.setAttribute("http-equiv", "Content-Security-Policy");
  meta.setAttribute("content", "default-src 'none'; script-src 'unsafe-inline';");
  contentDoc.head.appendChild(meta);
  return dom;
}

export async function solveVqd(challengeBase64, ua) {
  const js = Buffer.from(challengeBase64, "base64").toString("utf-8");
  const dom = makeDom();
  try {
    const result = await dom.window.eval(js);

    const hashes = [ua, result.client_hashes[1], result.client_hashes[2]].map((t) =>
      createHash("sha256").update(t).digest("base64")
    );
    result.client_hashes = hashes;

    if (result.meta && typeof result.meta === "object") {
      result.meta.origin = "https://duck.ai";
      result.meta.stack =
        "l@https://duck.ai/dist/duckai-dist/entry.duckai.c9340e95bd2f7fdc3302.js:2:1308110\n";
      result.meta.duration = String(20 + Math.floor(Math.random() * 30));
    }

    return Buffer.from(JSON.stringify(result)).toString("base64");
  } finally {
    try {
      dom.window.close();
    } catch {}
  }
}
